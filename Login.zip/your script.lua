
function lq()

function unXXX(str64)
    local b64chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    local temp={}
    for i=1,64 do
        temp[string.sub(b64chars,i,i)] = i
    end
    temp['=']=0
    local str=""
    for i=1,#str64,4 do
        if i>#str64 then
            break
        end
        local data = 0
        local str_count=0
        for j=0,3 do
            local str1=string.sub(str64,i+j,i+j)
            if not temp[str1] then
                return
            end
            if temp[str1] < 1 then
                data = data * 64
            else
                data = data * 64 + temp[str1]-1
                str_count = str_count + 1
            end
        end
        for j=16,0,-8 do
            if str_count > 0 then
                str=str..string.char(math.floor(data/math.pow(2,j)))
                data=math.fmod(data,math.pow(2,j))
                str_count = str_count - 1
            end
        end
    end
 
    local last = tonumber(string.byte(str, string.len(str), string.len(str)))
    if last == 0 then
        str = string.sub(str, 1, string.len(str) - 1)
    end
    ddd=str
end
 lqSJ = math.random(2685355,99999999)
 lqc=io.open('/storage/emulated/0/.87356171_1','r')
 if lqc == nil then
   lqc=io.open('/storage/emulated/0/Android/.87356171_int','w')
   lqc:write(lqSJ*6-967)
   lqc=io.open('/storage/emulated/0/.87356171_1','w')
   lqc:write(lqSJ*6-967)
   lqd = io.open('/storage/emulated/0/Android/.87356171_int','r')
   lqdm = lqd:read('*a')
   lqd:close()
 else
  abc=io.open('/storage/emulated/0/Android/.87356171_int','w')
  if abc == nil then
   lqdd = io.open('/storage/emulated/0/.87356171_1','r')
   lqdmm = lqdd:read('*a')
   lqdd:close()
   lqd = io.open('/storage/emulated/0/Android/.87356171_int','w')
   lqd:write(lqdmm)
   lqd:close()
   end
   lqd = io.open('/storage/emulated/0/Android/.87356171_int','r')
   lqdm = lqd:read('*a')
   lqd:close()
   lqdd = io.open('/storage/emulated/0/.87356171_1','r')
   lqdmm = lqdd:read('*a')
   lqdd:close()
   yanzheng = lqdm == lqdmm
   if yanzheng == true then print("") else
   lqd = io.open('/storage/emulated/0/Android/.87356171_int','w')
   lqd:write(lqdmm)
   lqd:close()
   end
   lqd = io.open('/storage/emulated/0/Android/.87356171_int','r')
   lqdm = lqd:read('*a')
   lqd:close()
 end
 lqdm = (lqdm + 967)/6
 lqs = io.open('/storage/emulated/0/Android/.87356171_1_dll','r')
 kom=[==[
██████████████
████▄▄█████▄▄█
██   ▼▼▼▼▼▼▼
██  Contact(ติดต่อ)
██  Telegram:Avartar_S
██  FB:Avartar Sun
██  YT:Avartar
██    ▲▲▲▲▲▲▲
██████████████
 ]==]
 if lqs == nil then
   lqsa=gg.alert('✵ ━ เปิดใช้งาน ( เช่าสคริปต์ ) รหัสบัตรรึไม่ ━ ✵','เปิดใช้งาน','ยกเลิก')
   if lqsa ~= 1 then gg.alert('꒰ ❌ ꒱  ≫ การเปิดใช้งานล้มเหลว') gg.toast("❌❌❌") print(kom) os.exit()
   else
     lqv = gg.prompt({'✎กรุณาป้อนรหัสที่รับจากผู้ขาย : ','✎ID(คัดลอกให้พ่อค้า) :  ' .. lqdm},{[1]='',[2]= lqdm },{[1] = 'text',[2] = 'text'})
     if lqv == nil then gg.toast('❌เปิดไม่สำเร็จ❌')  gg.toast("❌❌❌") os.exit() end
     if lqv[1] == '' then gg.alert('꒰ ❌ ꒱  ≫ รหัสผ่านต้องไม่ว่างเปล่า') gg.toast("❌❌❌") print(kom) os.exit() end
     unXXX(lqv[1])
     local lqB = ddd
     local lqC = lqdm
     pd = tonumber(lqB)
     if pd ~= lqB then gg.alert('꒰ ❌ ꒱  ≫ รหัสผ่านผิดพลาดติดต่อผู้ขาย') gg.toast("❌❌❌") print(kom) os.exit() end
     lqD = pd
     lqA = lqD
     unXXX("NDExODQ0")
          zcj = tonumber(ddd)
     if zcj ~= ddd then gg.alert('꒰ ❌ ꒱  ≫ รหัสเปิดใช้งานผิดพลาด') print(kom) os.exit() end
     aaa = (1*lqdm+zcj)..''
     abd = (3*lqdm+zcj)..''
     bbb = (7*lqdm+zcj)..''
     acf = (15*lqdm+zcj)..''
     ccc = (30*lqdm+zcj)..''
     ggg = (60*lqdm+zcj)..''
     ddd = (999*lqdm+zcj)..''
     if lqA == aaa then
     aaaa = 1
     gg.alert("꒰ ✅ ꒱  ≫ เปิดใช้งานการ์ดรายวันขอบคุณที่ใช้งาน\n-Login System By Avartar",'กำหนด')
     else
     	if lqA == abd then
     aaaa = 3
     gg.alert("꒰ ✅ ꒱  ≫ เปิดใช้งานการ์ดสามวันขอบคุณที่ใช้งาน\n-Login System By Avartar",'กำหนด')
     else
       if lqA == bbb then
       aaaa = 7
       gg.alert("꒰ ✅ ꒱  ≫ เปิดใช้งานการ์ดรายอาทิตย์ขอบคุณที่ใช้งาน-Login System By Avartar",'กำหนด')
       else
       if lqA == acf then
     aaaa = 15
     gg.alert("꒰ ✅ ꒱  ≫ เปิดใช้งานการ์ดสิบห้าวันขอบคุณที่ใช้งาน\n-Login System By Avartar",'กำหนด')
     else
         if lqA == ccc then
         aaaa = 30
         gg.alert("꒰ ✅ ꒱  ≫ เปิดใช้งานการ์ดรายเดือนขอบคุณที่ใช้งาน\n-Login System By Avartar",'กำหนด')
         else
        if lqA == ggg then
         aaaa = 60
         gg.alert("꒰ ✅ ꒱  ≫ เปิดใช้งานการ์ดรายเดือนขอบคุณที่ใช้งาน\n-Login System By Avartar",'กำหนด')
         else
         if lqA == ddd then
         aaaa = 999
         gg.alert("꒰ ✅ ꒱  ≫ เปิดใช้งานการ์ดถาวรขอบคุณที่ใช้งาน\n-Login System By Avartar",'กำหนด')
         else
           gg.alert('꒰ ❌ ꒱  ≫ รหัสเปิดใช้งานผิดพลาดโปรดติดต่อผู้ขาย') gg.toast("❌❌❌") os.exit()
         end
       end
       end
       end
     end
   end
   end
   ms = aaaa*24*60*60
   Yz = ((os.time() + ms)*lqdm)+lqdm..''
   Yza = Yz
   Yzb =io.open('/storage/emulated/0/Android/.87356171_1_dll','w')
   Yzb:write(Yza)
   Yzb:close()
   Yzb =io.open('/storage/emulated/0/.87356171_2','w')
   Yzb:write(100000000-(Yza-lqdm))
   Yzb:close()
 else
   Yzb =io.open('/storage/emulated/0/.87356171_2','r')
   if Yzb == nil then
   os.remove("/storage/emulated/0/.87356171_2")    
   os.remove("/storage/emulated/0/Android/.87356171_1_dll")
   os.remove("/storage/emulated/0/.87356171_1")    
   os.remove("/storage/emulated/0/Android/.87356171_int")
   os.exit()
   end
   YZZZ=Yzb:read('*a')
   Yzb:close()
   Yzd=io.open('/storage/emulated/0/Android/.87356171_1_dll','r')
   Yzda=Yzd:read('*a')
   Yzd:close()
   YZYZ=Yzda-lqdm+YZZZ
   if YZYZ ~=100000000 then
   os.remove("/storage/emulated/0/.87356171_2")    
   os.remove("/storage/emulated/0/Android/.87356171_1_dll")
   os.remove("/storage/emulated/0/.87356171_1")    
   os.remove("/storage/emulated/0/Android/.87356171_int")
   print("อย่าเปลี่ยนแปลงข้อมูลนะแจ๊ะ 🔥🧸")
   os.exit()
   end
   Yzd=io.open('/storage/emulated/0/Android/.87356171_1_dll','r')
   Yzda=Yzd:read('*a')
   Yzd:close()
   Yzf = os.time()
   Yzda = (Yzda-lqdm)/lqdm
   YZZ = Yzda
   YZA = (Yzda - Yzf)/3600/24
   YZB = YZA*24*3600
    YZC = (Yzda - Yzf -YZB)/60/60
    YZD = YZC*3600
    YZE = (Yzda - Yzf -YZB - YZD)/60
    YZF = YZE*60
    YZG = Yzda - Yzf -YZB - YZD -YZF
   if Yzda > Yzf then gg.alert('↻ เหลือเวลาการใช้งาน'.. YZA ..'วัน' .. YZC .. 'ชั่วโมง' .. YZE .. 'นาที' .. YZG .. 'วินาที')
     else
       gg.alert('❌ การใช้งานของคุณหมดอายุแล้ว ❌')
       print(kom)
   os.remove("/storage/emulated/0/.87356171_2")    
   os.remove("/storage/emulated/0/Android/.87356171_1_dll")
   os.remove("/storage/emulated/0/.87356171_1")    
   os.remove("/storage/emulated/0/Android/.87356171_int")
       os.exit()
     end
 end
end
lq()

--( นำสคริปต์ว่างตรงนี้ )--















function setvalue(address,flags,value) local Sql = {} Sql[1] = {} Sql[1].address = address Sql[1].flags = flags Sql[1].value = value gg.setValues(Sql) end   

if os.date("%Y%m%d")>"20220310" then
gg. alert ("✦——————♛——————✦\n \n⚙️สคริปต์ :: หมดอายุแล้ว \n \n🏆🅈🄾🅄🅃🅄🄱🄴 ​  ::   𝗕𝗢𝗢𝗠𝗦𝗟 \n \n👑🄵🄰🄲🄴🄱🄾🄾🄺 ​::  คุณ ชื่ออะไร \n \n✦—————————————✦","END")
os.etit()
end 




function V1 ()
menu = gg.choice({ 
	"🔻เริ่มเมนูโปร🔻", 
	"📴ออกจากสคริปต์📴"
	}, nil,os.date" 🔰sᴄʀɪᴘᴛ ᴘʀᴏ ʟɪɴᴇ ʀᴀɴɢᴇʀ ᴠ7.8.2 🔰                                                                                                                                                                                                                                            🎬📚  YOUTUBE :: BOOMSL  📚🎬") 
	if menu == nil then else
	if menu == 1 then START() end
	if menu == 2 then mb1() end
  end
  PGM = -1
 end
function mb1()
print("━━━━━━━━━━━━━━━━━━━━━\n  \n⚙️ติดต่อเช่าโปรได้ที่⚙️ \n \n🏆ʏᴏᴜᴛᴜʙᴇ ​  ::   ʙᴏᴏᴍsʟ \n \n👑ғᴀᴄᴇʙᴏᴏᴋ ​::  คุณ ชื่ออะไร \n \n━━━━━━━━━━━━━━━━━━━━━") 
os.exit() 
end 
function mb2()
os.exit() 
end 

--Code Value LRG
 
_Spr1 = 0x3689c0                
_Spr2 = 0x596af4
_Spr3 = 0x367b6c
_Spr4 = 0x3f33f4
_Spr44 = 0x3f33f4
_Spr5 = 0x3b9074
_Spr6 = 0xe80c28
_Spr7 = 0x8a3ff0





function START()
Hack = gg.multiChoice({
ME1.." 👥 ปล่อยตัว 0วิ ",
ME2.." 🥊 ตีแรง 999 ",
ME3.." 🗼 ตีป้อมทีเดียว ",
ME4.." 👻 ตายออโต้ ",
ME5.." 🚀 จรวดไม่แรง ",
ME6.." 📽️ ลบประวัติ ",
ME7.." ⏰ เร่งเวลาเกม ",
"⪩ ออก"
},nil,"ʜᴀᴄᴋ ʟɪɴᴇ ʀᴀɴɢᴇʀs\nʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")

if Hack[1] then YHRT1() 
end
if Hack[2] then YHRT2() 
end
if Hack[3] then YHRT3() 
end
if Hack[4] then YHRT4() 
end
if Hack[5] then YHRT5() 
end
if Hack[6] then YHRT6() 
end
if Hack[7] then YHRT7() 
end
if Hack[8] then YHRT8() 
end
end


ME1 = "〘 🔵 〙"
function YHRT1()
if ME1 == "〘 🔵 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr1
setvalue(so + py, 16, -27)    
ME1 = "〘 🔴 〙"
gg.sleep(100)
gg.toast("ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
elseif ME1 == "〘 🔴 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr1
setvalue(so + py, 16, 0)    
ME1 = "〘 🔵 〙"    
gg.sleep(100)
gg.toast(" ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
end
end



ME2 = "〘 🔵 〙"
function YHRT2()
if ME2 == "〘 🔵 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr2
setvalue(so + py, 16, 9999999)        
ME2 = "〘 🔴 〙"
gg.sleep(100)
gg.toast("ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
elseif ME2 == "〘 🔴 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr2
setvalue(so + py, 16, 0)        
ME2 = "〘 🔵 〙"    
gg.sleep(100)
gg.toast(" ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
end
end


ME3 = "〘 🔵 〙"
function YHRT3()
if ME3 == "〘 🔵 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr3
setvalue(so + py, 16, 99999)        
ME3 = "〘 🔴 〙"
gg.sleep(100)
gg.toast(" ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
elseif ME3 == "〘 🔴 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr3
setvalue(so + py, 16, 0)        
ME3 = "〘 🔵 〙"    
gg.sleep(100)
gg.toast(" ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
end
end


ME4 = "〘 🔵 〙"
function YHRT4()
if ME4 == "〘 🔵 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr4
setvalue(so + py, 16, 9999999)        
ME4 = "〘 🔴 〙"
gg.sleep(100)
gg.toast(" ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
elseif ME4 == "〘 🔴 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr4
setvalue(so + py, 16, -100)        
ME4 = "〘 🔵 〙"    
gg.sleep(100)
gg.toast(" ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
end
end






ME5 = "〘 🔵 〙"
function YHRT5()
if ME5 == "〘 🔵 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr5
setvalue(so + py, 16, -9999999)      
gg.sleep(100)
gg.toast(" ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ ")
ME5 = "〘 🔴 〙"
elseif ME5 == "〘 🔴 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr5
setvalue(so + py, 16, 90)        
ME5 = "〘 🔵 〙"
gg.sleep(100)    
gg.toast(" ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
end
end


ME6 = "〘 🔵 〙"
function YHRT6()
if ME6 == "〘 🔵 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr6
setvalue(so + py, 16, 1.40129846e-40)        
ME6 = "〘 🔴 〙"
gg.sleep(100)
gg.toast(" ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
elseif ME6 == "〘 🔴 〙" then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr6
setvalue(so + py, 16, 2.24207754e-43)        
ME6 = "〘 🔵 〙"    
gg.sleep(100)
gg.toast(" ʏᴏᴜᴛᴜʙᴇ : ʙᴏᴏᴍsʟ")
end
end
    
    
 

ME7 = "〘 🔵 〙"
function YHRT7() 
Scp = gg.prompt({"⏰ เร่งเวลาเกม : [10000;1000000]",},{1000000},{"number",})
so = gg.getRangesList("libgame.so")[1].start
py = _Spr7
setvalue(so + py, 16, Scp[1])
gg.sleep(100)
gg.toast(" ⏰ เร่งเวลาเกม ")      
end


function YHRT8() 
F = gg.alert(" ᴏғғ ᴏʀ ᴏᴘᴇɴ ғᴜɴᴄᴛɪᴏɴ ᴛᴏ sᴄʀɪᴘᴛ \n( ปิด หรือ เปิด สคริปต์ ฟังก์ชั่น ทั้งหมด)", "🔔ᴏғғ ғᴜɴᴄᴛɪᴏɴ\n( ปิดทุกฟังชั่น )","⚠️ᴏᴘᴇɴ ғᴜɴᴄᴛɪᴏɴ\n( เปิดฟังชั่นทิ้งไว้ ) ")
if F == 1 then
so = gg.getRangesList("libgame.so")[1].start
py = _Spr1
setvalue(so + py, 16, 0)    
so = gg.getRangesList("libgame.so")[1].start
py = _Spr2
setvalue(so + py, 16, 0)        
so = gg.getRangesList("libgame.so")[1].start
py = _Spr3
setvalue(so + py, 16, 0)        
so = gg.getRangesList("libgame.so")[1].start
py = _Spr4
setvalue(so + py, 16, -100)        
so = gg.getRangesList("libgame.so")[1].start
py = _Spr5
setvalue(so + py, 16, 90)        
so = gg.getRangesList("libgame.so")[1].start
py = _Spr6
setvalue(so + py, 16, 2.24207754e-43)        
so = gg.getRangesList("libgame.so")[1].start
py = _Spr7
setvalue(so + py, 16, 1000000) 
gg.toast(" 🔔 ปิดทุกฟังชั่น ")     
print("━━━━━━━━━━━━━━━━━━━━━\n  \n⚙️ติดต่อเช่าโปรได้ที่⚙️ \n \n🏆ʏᴏᴜᴛᴜʙᴇ ​  ::   ʙᴏᴏᴍsʟ \n \n👑ғᴀᴄᴇʙᴏᴏᴋ ​::  คุณ ชื่ออะไร \n \n━━━━━━━━━━━━━━━━━━━━━") 
os.exit()
elseif F == 2 then  
START()
gg.toast(" ⚠️ เปิดฟังชั่นทิ้งไว้ ")     
end  
end
while true do
if gg.isVisible(true)then
YHRT = 1
gg.setVisible(false)
end
if YHRT == 1 then START() end
YHRT = -1
end

V1()
while true do
if gg.isVisible(true)then
YHRT = 1
gg.setVisible(false) 
end
if YHRT == 1 then V1() end
YHRT = -1
end
